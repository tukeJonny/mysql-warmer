# mysql-warmer
mysql warmup implementation written in golang
